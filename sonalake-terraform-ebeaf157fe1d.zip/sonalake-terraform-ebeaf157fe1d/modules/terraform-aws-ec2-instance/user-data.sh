#!/usr/bin/env bash
cat > /usr/local/sbin/ebs-volumes-init.sh << 'EOF'
#!/usr/bin/env bash

set -euo pipefail

# log all output to a logfile
exec 3>&1 4>&2
trap 'exec 2>&4 1>&3' EXIT HUP INT QUIT RETURN
exec 1>>/root/diskinit.log 2>&1

progname=$( basename "$0" )
reboot_flag="false"

logger() {
    echo "$(date "+%F %T") user-data/$progname: $@"
}

instance_id=$( curl -s http://169.254.169.254/latest/meta-data/instance-id )
region=$( curl -s http://169.254.169.254/latest/meta-data/placement/region )
filter="Name=attachment.instance-id,Values=$instance_id Name=tag-key,Values=Mountpoint"
query="Volumes[].{ID:VolumeId,Mountpoint:Tags[?Key == 'Mountpoint'].Value|[0]}"
volume_data=$( aws --region $region ec2 describe-volumes --filter $filter --query "$query" --output text )
device_data=$( echo "$volume_data" | sed -e 's|-||g' -e 's|^|/dev/disk/by-id/nvme-Amazon_Elastic_Block_Store_|' )
swap_device=$( echo "$device_data" | grep swap | cut -d$'\t' -f1 )

if [ -z "$volume_data" ]; then
  logger "ERROR: no volume data"
  exit 1
fi

# create swap fstab entry
if ! grep -q $swap_device /etc/fstab; then
  echo "$swap_device swap swap defaults 0 0" >> /etc/fstab
fi

logger "Initializing swap on device $swap_device"
swapoff -av
mkswap $swap_device
swapon -av

# initialize all other volumes
while read -r line; do
  device=$( echo "$line" | cut -d$'\t' -f1 )
  mountpoint=$( echo "$line" | cut -d$'\t' -f2 )

  if ! grep -q $device /etc/fstab; then
    logger "Initializing $mountpoint on device $device"
    mkfs.xfs $device

    # migrate data if mountpoint exists already
    if [ -d $mountpoint ]; then
      logger "Migrating original $mountpoint to new device $device"
      mkdir /tempmount
      mount $device /tempmount
      rsync -aqx $mountpoint/ /tempmount/
      umount /tempmount
      rmdir /tempmount
      mv $mountpoint $mountpoint.orig
      reboot_flag="true"
    fi

    logger "Attaching new $mountpoint on device $device"
    mkdir $mountpoint
    mount $device $mountpoint
    echo "$device $mountpoint xfs noatime,nodiratime 0 2" >> /etc/fstab
  fi

done < <( echo "$device_data" | grep -v swap )

if [ "$reboot_flag" = "true" ]; then
  logger "Detected data migration to a new volume, rebooting .."
  reboot
fi
EOF

echo "/usr/local/sbin/ebs-volumes-init.sh" >> /etc/rc.d/rc.local
chmod 755 /etc/rc.d/rc.local /usr/local/sbin/ebs-volumes-init.sh
# Waiting 30 for EBS volumes to get attached/resized
sleep 30
/usr/local/sbin/ebs-volumes-init.sh

