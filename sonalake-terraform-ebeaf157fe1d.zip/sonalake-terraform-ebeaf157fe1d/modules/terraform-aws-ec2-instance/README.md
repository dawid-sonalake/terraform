# AWS EC2 Instance Terraform module

Terraform module which creates EC2 instance on AWS.

## Features

- Auto-generate instance name if not defined
- Auto-set optimal swap size based on instance type
- Auto-resize swap volumes on instance change
- Auto-create/attach encrypted base EBS volumes `/`, `/tmp`, `/var/log`, `/home`, mount them and migrate data to them (done in user-data script)
- Automatically create attach encrypted extra EBS volumes
- Automatically format/mount extra EBS volumes in O/S on first boot
- Create IAM instance profile and attach SSM policies to make instance SSM agent work out of the box. Set SSM OS/package auto-update. Module also outputs SSM command to be used to connect to the instance

... and others.

## Usage

### Minimal configuration

```hcl
module "instance" {
  source    = "../path-to-modules/terraform-aws-ec2-instance"
  subnet_id = "subnet-id"
}
```

In this case:

- instance name is auto-generated
- default `domain_name` (see `inputs`) is used

### Advanced configuration

```hcl
module "instance" {
  source                 = "../../../../modules/ec2-instance"
  subnet_id              = "subnet-id"
  name                   = "web1-dev-ir"
  domain_name            = "sonalake.dev"
  instance_type          = "t3.small"
  aws_profile_txt        = var.aws_profile
  vpc_security_group_ids = ["sg-id"]

  tags = merge(
    var.tf_default_tags,
    {
      "Role"        = "web_server"
      "Environment" = "dev"
      "Project"     = "Very important project"
    },
  )
}
```

- For all options see `inputs` section


## Notes

- When decreasing instance type, swap volume must be tainted (recreated) as AWS does not allow decreasing EBS volumes size. To do that, use the following command before running `terraform apply` / `terragrunt apply` apply when decreasing EC2 instance size:

```
terraform taint 'module.instance.aws_ebs_volume.this["swap"]'
terraform apply
```

<!-- BEGINNING OF PRE-COMMIT-TERRAFORM DOCS HOOK -->
## Requirements

| Name | Version |
|------|---------|
| terraform | >= 0.12.6 |
| aws | >= 2.65 |
| random | >= 3.0 |

## Providers

| Name | Version |
|------|---------|
| aws | >= 2.65 |
| random | >= 3.0 |

## Modules

No Modules.

## Resources

| Name |
|------|
| [aws_caller_identity](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/data-sources/caller_identity) |
| [aws_ebs_volume](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/ebs_volume) |
| [aws_ec2_instance_type](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/data-sources/ec2_instance_type) |
| [aws_eip](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/eip) |
| [aws_iam_instance_profile](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/iam_instance_profile) |
| [aws_iam_policy_document](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/data-sources/iam_policy_document) |
| [aws_iam_role](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/iam_role) |
| [aws_iam_role_policy](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/iam_role_policy) |
| [aws_iam_role_policy_attachment](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/iam_role_policy_attachment) |
| [aws_instance](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/instance) |
| [aws_region](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/data-sources/region) |
| [aws_route53_record](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/route53_record) |
| [aws_route53_zone](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/data-sources/route53_zone) |
| [aws_ssm_association](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/ssm_association) |
| [aws_ssm_parameter](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/data-sources/ssm_parameter) |
| [aws_volume_attachment](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/volume_attachment) |
| [random_string](https://registry.terraform.io/providers/hashicorp/random/latest/docs/resources/string) |

## Inputs

| Name | Description | Type | Default | Required |
|------|-------------|------|---------|:--------:|
| ami | ID of AMI to use for the instance, by default latest amazon linux 2 ami is used | `string` | `"amazon-linux-2-latest"` | no |
| attach\_eip | Attach Elastic IP | `bool` | `false` | no |
| aws\_profile\_txt | AWS profile to create in DNS TXT record to support AWS SSM resolving | `string` | `""` | no |
| cpu\_credits | CPU credits, standard/unlimited | `string` | `"standard"` | no |
| disable\_api\_termination | EC2 Instance Termination Protection | `bool` | `false` | no |
| domain\_name | Route53 domain name where instance DNS records will be created | `string` | `""` | no |
| instance\_profile\_policies\_arn | Attach policies to instance profile | `list(string)` | <pre>[<br>  "arn:aws:iam::aws:policy/AmazonSSMManagedInstanceCore"<br>]</pre> | no |
| instance\_profile\_policy\_inline | The IAM Instance Profile additional inline Policy to launch the instance with | `string` | `"{\n  \"Version\": \"2012-10-17\",\n  \"Statement\": [\n    {\n      \"Sid\": \"AllowDescribeVolumes\",\n      \"Effect\": \"Allow\",\n      \"Action\": \"ec2:DescribeVolumes\",\n      \"Resource\": \"*\"\n    }\n  ]\n}\n"` | no |
| instance\_type | The type of instance to start | `string` | `"t3a.nano"` | no |
| key\_name | The key pair name to use for the instance | `string` | `"ansible"` | no |
| monitoring | EC2 instance detailed monitoring | `bool` | `false` | no |
| name | Instance name, by default instance name is generated randomly | `string` | `"generated"` | no |
| region\_data | Region specific variables | `map(map(string))` | <pre>{<br>  "eu-central-1": {<br>    "region_id_short": "fr"<br>  },<br>  "eu-west-1": {<br>    "region_id_short": "ir"<br>  }<br>}</pre> | no |
| root\_block\_device | Customize details about the root block device of the instance | `map(string)` | <pre>{<br>  "delete_on_termination": true,<br>  "encrypted": true,<br>  "volume_size": 8,<br>  "volume_type": "gp3"<br>}</pre> | no |
| ssm\_agent\_auto\_update | SSM Agent auto update | `bool` | `true` | no |
| ssm\_agent\_update\_schedule\_expression | A cron expression when the association will be applied to the target | `string` | `"cron(0 2 ? * SUN *)"` | no |
| subnet\_id | The VPC Subnet ID to launch in | `string` | n/a | yes |
| tags | A mapping of tags to assign to the resource | `map(string)` | <pre>{<br>  "Terraform": "True"<br>}</pre> | no |
| user\_data | The user data to provide when launching the instance, by default module's user-data will be used to auto-initialize ebs volumes | `string` | `"ebs-volumes-init"` | no |
| volume\_encryption | EBS volumes encryption default if not explicitly specified in volume settings | `bool` | `true` | no |
| volumes\_base | Base volumes present on all instances | `list(map(string))` | <pre>[<br>  {<br>    "mountpoint": "swap",<br>    "size": "auto",<br>    "type": "gp3"<br>  },<br>  {<br>    "mountpoint": "/tmp",<br>    "size": 5,<br>    "type": "gp3"<br>  },<br>  {<br>    "mountpoint": "/var/log",<br>    "size": 6,<br>    "type": "gp3"<br>  },<br>  {<br>    "mountpoint": "/home",<br>    "size": 10,<br>    "type": "gp3"<br>  }<br>]</pre> | no |
| volumes\_extra | Extra volumes. `type`, `size`, `mountpoint` required. `encrypted` optional (default: true) | `list(map(string))` | `[]` | no |
| vpc\_security\_group\_ids | A list of security group IDs to associate with | `list(string)` | `null` | no |

## Outputs

| Name | Description |
|------|-------------|
| id | Instance ID |
| name | Instance name |
| private\_dns | Instance private DNS |
| private\_ip | Instance private IP address |
| public\_aws\_dns | Instance AWS generated public DNS |
| public\_dns | Instance public DNS |
| public\_ip | Instance public IP address |
| ssm\_command | AWS SSM command to connect to the instance |
| ssm\_helper\_command | AWS SSM helper (ssm) command to connect to the instance |
<!-- END OF PRE-COMMIT-TERRAFORM DOCS HOOK -->

## Authors
Module managed by [Chris Mazanec](https://github.com/chrismazanec).

